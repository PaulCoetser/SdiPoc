﻿import { Component, ViewChild, Injector, Output, EventEmitter, ElementRef } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { OnboardingServiceProxy, SDI_ApplicationDto, SDI_DeveloperDto } from '@shared/service-proxies/service-proxies';
import { AppComponentBase } from '@shared/app-component-base';

import { SDIPasscodeOutput,
         SDIRegistrationServiceProxy,
         Developer,
         Application } from '@shared/service-proxies/sdi-service-proxies';

import * as _ from "lodash";

@Component({
  selector: 'generate-passcode-modal',
  templateUrl: './generate-passcode.component.html'
})
export class GeneratePasscodeComponent extends AppComponentBase {

    @ViewChild('generatePasscodeModal') modal: ModalDirective;
    @ViewChild('modalContent') modalContent: ElementRef;

    @Output() modalSave: EventEmitter<any> = new EventEmitter<any>();

    active = false;
    saving = false;
    developerId: string;
    application: SDI_ApplicationDto;

    constructor(
        injector: Injector,
        private _onboardingService: OnboardingServiceProxy,
        private _sdiRegistrationService: SDIRegistrationServiceProxy,
    ) {
        super(injector);
    }

    show(developer: SDI_DeveloperDto, application: SDI_ApplicationDto): void {
        this.active = true;
        this.modal.show();
        this.developerId = developer.developerIdFromSdiPlatform;
        this.application = application;
    }

    onShown(): void {
        $.AdminBSB.input.activate($(this.modalContent.nativeElement));
    }

    save(): void {
        this.saving = true;

        this._sdiRegistrationService.generatePasscode(this.developerId, this.application.applicationIdFromSdiPlatform)
        .finally(() => { this.saving = false; })
        .subscribe((result: SDIPasscodeOutput) => {
            if (result.passcode !== undefined) {
                this.application.passcode = result.passcode;
            }
            this._onboardingService.updateApplication(this.application)
                .finally(() => { this.saving = false; })
                .subscribe((resultSave: SDI_ApplicationDto) => {
                    this.notify.info(this.l('SavedSuccessfully'));
                    this.close();
                    this.modalSave.emit(null);
                });
        });
    }

    close(): void {
        this.active = false;
        this.modal.hide();
    }
}
